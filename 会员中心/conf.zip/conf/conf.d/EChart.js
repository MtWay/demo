    
        // 路径配置
        require.config({
            paths: {
                echarts: '${staticServer}/web/hxdata/echart/dist'
            }
        });
         // 使用
        require(
            [
                'echarts',
                'echarts/chart/line' // 
            ],
            function (ec) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('container')); 
                
                var option = {
				
		title : {
                'text':null,//一级标题的文本
                'subtext':'数据来自华夏二手车网',//二级标题
                'x':'center',
                'textStyle':{
			    fontSize: 18,
			    fontWeight: 'bolder',
			    color: '#ec6618',
			    },
            },	
	//轴线显示		
    tooltip : {
        trigger: 'axis'
		formatter : function() {
				var year = Highcharts.dateFormat('%y', this.x);
				var month = Highcharts.dateFormat('%m', this.x);
				return '<b>' + year + '年' + month + '月' + '</b><br/>'
						+ this.series.name + '（均价）: ' + this.y + '万元';
			}
    },
   
    toolbox: {
        show : true,
        feature : {
            mark : {show: false},
            dataView : {readOnly:false},
            magicType : {show: false, type: ['line', 'bar', 'stack', 'tiled']},
            restore : {show: false},
            saveAsImage : {show: false},
        }
    },
    calculable : false,
    dataZoom : {
        show : true,
        realtime : true,
        start : ${hxdataVo.latelyw},//96.96969696969697
        end : 100,
         height: 30,
    },
   
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : ${date!""}//2015-11-09
        },
          
    ],
    yAxis : [
        {
            type : 'value',
            
        },
		 
		
		
    ],
    series : [
        {
            name:'搜索指数',
            type:'line',
            data:${kucun!""},
			// markLine : {
            //    data : [
              //      {type : 'average', name: '平均值'}
              //  ]
          // }
			
			
        },
		 
       
    ]
};

                // 为echarts对象加载数据 
                 
                myChart.setOption(option); 
				

                    
            }
        );
        
        function lately(mm){
       
         // 使用
        require(
            [
                'echarts',
                'echarts/chart/line' // 
            ],
            function (ec) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('main')); 
                
                var option = {
				
		title : {
                'text':'${hxdataVo.keyword}',//DB9
                'subtext':'数据来自华夏二手车网',
                'x':'center',
                'textStyle':{
			    fontSize: 18,
			    fontWeight: 'bolder',
			    color: '#ec6618',
			    },
            },	
				
    tooltip : {
        trigger: 'axis'
    },
   
    toolbox: {
        show : true,
        feature : {
            mark : {show: false},
            dataView : {readOnly:false},
            magicType : {show: false, type: ['line', 'bar', 'stack', 'tiled']},
            restore : {show: false},
            saveAsImage : {show: false},
        }
    },
    calculable : false,
    dataZoom : {
        show : true,
        realtime : true,
        start : mm,
        end : 100,
         height: 30,
    },
   
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : ${date!""}
        },
          
    ],
    yAxis : [
        {
            type : 'value',
            
        },
		 
		
		
    ],
    series : [
        {
            name:'搜索指数',
            type:'line',
            data:${kucun!""},
			// markLine : {
            //    data : [
              //      {type : 'average', name: '平均值'}
              //  ]
          // }
			
			
        },
		 
       
    ]
};

                // 为echarts对象加载数据 
                 
                myChart.setOption(option); 
				

                    
            }
        );
        
        }